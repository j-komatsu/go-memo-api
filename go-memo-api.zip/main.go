package main

import (
    "github.com/gin-gonic/gin"
    "go-memo-api/config"
    "go-memo-api/routes"
)

func main() {
    db := config.InitDB()
    router := gin.Default()
    routes.SetupRoutes(router, db)
    router.Run(":8080")
}
