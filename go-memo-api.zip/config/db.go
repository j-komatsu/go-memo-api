package config

import (
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
    "log"
    "go-memo-api/models"
)

func InitDB() *gorm.DB {
    db, err := gorm.Open(sqlite.Open("database/notes.db"), &gorm.Config{})
    if err != nil {
        log.Fatal("Failed to connect to database")
    }
    db.AutoMigrate(&models.Note{})
    return db
}
